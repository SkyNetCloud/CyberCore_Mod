# Extended Crafting [![](http://cf.way2muchnoise.eu/full_268387_downloads.svg)](https://minecraft.curseforge.com/projects/extended-crafting)
Adds some new ways to craft items, as well as extra crafting items and utilities.
